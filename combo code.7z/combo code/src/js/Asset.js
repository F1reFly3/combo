/**
 * Asset handles images 
 */
const Asset = {
    _sprites: {
        camera_arm: {
            x: 32,
            y: 32,
            w: 32,
            h: 32
        },
        camera_head: {
            x: 0,
            y: 32,
            w: 21,
            h: 12
        },
        door: {
            x: 64,
            y: 0,
            w: 32,
            h: 32
        },
        floor: {
            x: 32,
            y: 0,
            w: 32,
            h: 32
        },
        player: {
            x: 64,
            y: 32,
            w: 21,
            h: 15
        },
        raven: {
            x: 96,
            y: 32,
            w: 18,
            h: 30
        },
        terminal: {
            x: 96,
            y: 0,
            w: 32,
            h: 32
        },
        wall: {
            x: 0,
            y: 0,
            w: 32,
            h: 32
        }
    },
    _img: {
    },

    _fontFamily: "Monaco,'Lucida Sans Typewriter','Andale Mono','Lucida Console','Courier New',Courier,monospace",

    _loadImage(src) {
        const img = new Image();
        img.src = src;
        return img;
    },

    drawSprite(name, ctx, x, y) {
        let sprite = this._sprites[name];
        ctx.drawImage(this._img._sprites, sprite.x, sprite.y, sprite.w, sprite.h, x, y, sprite.w, sprite.h);
    },

    drawSprite2(name, ctx, sx, sy, sw, sh, dx, dy, dw, dh) {
        let sprite = this._sprites[name];
        ctx.drawImage(this._img._sprites, sprite.x + sx, sprite.y + sy, sw, sh, dx, dy, dw, dh);
    },

    loadAllAssets() {
        Asset._img._sprites = Asset._loadImage('assets/sprites.png');
    },

    getFontString(pixels) {
        return '' + pixels + 'px ' + Asset._fontFamily;
    }
};
