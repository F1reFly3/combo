/**
 * Audio handles background music and sound effects.
 */
class Audio {
    constructor() {
        let ctxClass = (window.AudioContext || window.webkitAudioContext);
        if (ctxClass) {
            this.ctx = new ctxClass();
        } else {
            this.disabled = true;
            return;
        }

        this._sounds = {};
        [
            ['click',  0.1],
            ['bloop',  0.5],
            ['siren',  0.1],
            ['tri',    0.5],
            ['music',  0.4],
            ['m1',     1, 'music'],
            ['m2',     1, 'music'],
            ['m3',     1, 'music']
        ].forEach(([name, volume, parent]) => {
            this._sounds[name] = this.ctx.createGain();
            this._sounds[name].gain.value = volume;
            this._sounds[name].connect(parent ? this._sounds[parent] : this.ctx.destination);
        });

        this._musicNodes = [this._sounds.m1, this._sounds.m2, this._sounds.m3];
        this._musicIndex = 0;

        this._last = {
            click: 0
        };

        this._tracks = {
            game: [
                // Measure 1
                [22, 19], // C Eb
                [],
                [],
                [],
                [22, 15], // C G
                [21],     // C#
                [],
                [],
                [22, 19], // C Eb
                [],
                [16],     // F#
                [],
                [22, 15], // C G
                [],
                [14],     // Ab
                [],

                // Measure 2
                [22, 19], // C Eb
                [],
                [],
                [16],     // F#
                [22, 15], // C G
                [],
                [20],     // D
                [],
                [22, 19], // C Eb
                [14],     // Ab
                [],
                [16],     // F#
                [22, 15], // C G
                [],
                [21],     // C#
                [20]      // D
            ],
            death: [
                [22, 16],
                [21, 15],
                [22, 16],
                [21, 15],

                [22, 16],
                [19],
                [23, 17],
                [20],

                [24, 18],
                [21],
                [25, 19],
                [22],

                [26, 20],
                [23],
                [27, 21],
                [24],

                [28, 22],
                [25],
                [29, 23],
                [26],

                [30, 24],
                [27],
                [31, 25],
                [28],

                [],
                [],
                [],
                [],

                [],
                [],
                [],
                [],



                [],
                [],
                [],
                []
            ]
        };

        let track2 = this._tracks.game.map(x => {
            return x.map(y => y - 4);
        });
        track2[30] = [16];
        track2[31] = [15];

        let track3 = this._tracks.game.map((x, i) => {
            return x.map(y => y - 3);
        });

        this._tracks.game = this._tracks.game.concat(this._tracks.game).concat(track2).concat(track3);

        this._tracks.game.repeat = true;
        this._tracks.death.repeat = false;

        this._tickLength = 1/5;
        this._nextTick = this._tickLength;
    }

    update(delta) {
        if (this.disabled) return;

        if (game.player && game.player.dead) {
            this._sounds.music.gain.value = Math.max(0, 0.4 - game.deathFrame / 1000);
            if (this._track !== this._tracks.death) {
                this._track = this._tracks.death;
                this._tick = 0;
            }
        } else {
            this._sounds.music.gain.value = 0.4;
            if (this._track !== this._tracks.game) {
                this._track = this._tracks.game;
                this._tick = 0;
            }
        }

        if (this._nextTick - this.ctx.currentTime < 0.2) {
            this._musicIndex = (this._musicIndex + 1) % this._musicNodes.length;
            let node = this._musicNodes[this._musicIndex];
            this._scheduleForTick(this._track, this._tick, this._nextTick, this._tickLength, node);
            this._tick++;

            if (this._nextTick < this.ctx.currentTime) this._nextTick = this.ctx.currentTime;

            this._nextTick += this._tickLength;
        }
    }

    _scheduleForTick(track, tick, nextTick, tickLength, dest) {
        let notes = track.repeat ? track[tick % track.length] : track[tick];
        let noteLength = tickLength * 1.39;

        if (!notes) return;

        for (let i = 0; i < notes.length; i++) {
            let o = this.ctx.createOscillator();
            let freq = 988/1.06**notes[i];
            o.frequency.value = freq;
            o.type = 'triangle';
            o.connect(dest);
            o.start(nextTick);
            dest.gain.setValueAtTime(0,          nextTick);
            dest.gain.linearRampToValueAtTime(1, nextTick + noteLength * 0.05);
            dest.gain.setValueAtTime(1,          nextTick + noteLength * 0.95);
            dest.gain.linearRampToValueAtTime(0, nextTick + noteLength);

            o.stop(nextTick + noteLength);
        }
    }

    _playOscillatorSound(channel, type, freq, rampFreq, rampTime, length, timeSinceLast, timeOffset) {
        if (this.disabled) return;

        let time = timeOffset || this.ctx.currentTime;
        if (timeSinceLast && time - this._last[channel] < timeSinceLast) return;
        this._last[channel] = time;


        let o = this.ctx.createOscillator();
        o.frequency.setValueAtTime(freq, time);
        if (rampFreq) {
            o.frequency.exponentialRampToValueAtTime(rampFreq, time + rampTime);
        }
        o.type = type;
        o.connect(this._sounds[channel]);
        o.start(time);
        o.stop(time + length);
    }

    playClick() {
        let freq = 988/1.06**1;
        this._playOscillatorSound('click', 'sine', freq, freq * 0.6, 0.1, 0.01, 0.05);
    }

    playBloop() {
        let freq = 988/1.06**28;
        this._playOscillatorSound('bloop', 'square', freq, freq * 1.6, 0.2, 0.09);
    }

    playSiren() {
        let freq = 988/1.06**11;
        this._playOscillatorSound('siren', 'sawtooth', freq, freq * 2, 1.1, 0.65, 0.5);
    }

    playTri() {
        let time = this.ctx.currentTime;
        let freq1 = 988/1.06**10;
        let freq2 = 988/1.06**8;
        let freq3 = 988/1.06**2;
        this._playOscillatorSound('tri', 'square', freq1, 0, 0, 0.1, false, time);
        this._playOscillatorSound('tri', 'square', freq2, 0, 0, 0.1, false, time + 0.08);
        this._playOscillatorSound('tri', 'square', freq3, 0, 0, 0.2, false, time + 0.16);
    }
}
