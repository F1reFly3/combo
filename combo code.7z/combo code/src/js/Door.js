/**
 * Door handles the security doors, drawn on top of a floor tile, and can slide open
 * and closed.
 */
class Door {
    constructor(doorData) {
        this.u = doorData.u;
        this.v = doorData.v;
        this.type = doorData.type;
        this.exitDoor = doorData.exitDoor;
        this.entranceDoor = doorData.entranceDoor;

        if (this.exitDoor) this.locked = true;

        //if (this.type === 'h') {
            this.x = this.u * 32 + 32;
            this.y = this.v * 32 + 16;
        //} else {
        //    this.x = this.u * 32 + 16;
        //    this.y = this.v * 32 + 32;
        //}

  
        this.toggleRadius = 58;

        this.control = doorData.control;

        this.slide = 0;

        this.toggled = undefined;
    }

    update(delta) {
        let playerNear = Util.pointNearPoint(this, game.player, this.toggleRadius);

        if (playerNear && !game.levelComplete && !this.locked) {
            if (this.slide < 30) {
                this.slide = Math.min(30, this.slide + 32 * delta);
            }
        } else {
            if (this.slide > 0) {
                this.slide = Math.max(0, this.slide - 32 * delta);
            }
        }

        if (this.entranceDoor && this.slide === 0 && !Util.pointInBounds(game.player, game.level.enter)) {
            this.locked = true;
        }

        let terminalsLeft = 0;
        game.terminals.forEach(terminal => {
            if (!terminal.enabled) terminalsLeft++;
        });

        if (this.exitDoor && terminalsLeft === 0) {
            this.locked = false;
        }

        this.toggled = undefined;
    }

    render() {
        let slide = Math.floor(this.slide);


        //if (this.type === 'h') {
            game.ctx.save();
            game.ctx.translate(game.offset.x + this.x, game.offset.y + this.y);
            Asset.drawSprite2('door', game.ctx, slide, 0, 32 - slide, 32, -32, -16, 32 - slide, 32);
            game.ctx.rotate(Util.d2r(180));
            Asset.drawSprite2('door', game.ctx, slide, 0, 32 - slide, 32, -32, -16, 32 - slide, 32);

            if (this.locked) {
                game.ctx.fillStyle = 'rgba(204, 36, 36, 0.8)';
                game.ctx.fillRect(10, 8, 14, 2);
                game.ctx.fillRect(-24, 8, 14, 2);
                game.ctx.fillRect(10, -10, 14, 2);
                game.ctx.fillRect(-24, -10, 14, 2);
            }

            game.ctx.restore();
        //} else {
        //    game.ctx.save();
        //    game.ctx.translate(game.offset.x + this.x, game.offset.y + this.y);
        //    game.ctx.rotate(Util.d2r(90));
        //    game.ctx.drawImage(Asset.tile.door, slide, 0, 32 - slide, 32, -32, -16, 32 - slide, 32);
        //    game.ctx.rotate(Util.d2r(270));
        //    game.ctx.drawImage(Asset.tile.door, slide, 0, 32 - slide, 32, -32, -16, 32 - slide, 32);
        //    game.ctx.restore();
        //}
    }

    toggle() {
        this.toggled = true;
    }

    getLosEdges() {
        let cut = game.tileVisibilityInset;

        if (this.slide < 3) {
            return [
                // top edge
                {
                    p1: {
                        x: this.x - 32 - cut,
                        y: this.y - 12 + cut
                    },
                    p2: {
                        x: this.x + 32 + cut,
                        y: this.y - 12 + cut
                    }
                },
                {
                    p1: {
                        x: this.x - 32 - cut,
                        y: this.y + 12 - cut,
                    },
                    p2: {
                        x: this.x + 32 + cut,
                        y: this.y + 12 - cut
                    }
                }
            ];
        } else {
            return [
                {
                    p1: {
                        x: this.x - 32 - cut,
                        y: this.y - 12 + cut
                    },
                    p2: {
                        x: this.x - this.slide - cut,
                        y: this.y - 12 + cut
                    }
                },
                {
                    p1: {
                        x: this.x - this.slide - cut,
                        y: this.y - 12 + cut
                    },
                    p2: {
                        x: this.x - this.slide - cut,
                        y: this.y + 12 - cut
                    }
                },
                {
                    p1: {
                        x: this.x - 32 - cut,
                        y: this.y + 12 - cut
                    },
                    p2: {
                        x: this.x - this.slide - cut,
                        y: this.y + 12 - cut
                    }
                },
                {
                    p1: {
                        x: this.x + this.slide + cut,
                        y: this.y - 12 + cut
                    },
                    p2: {
                        x: this.x + 32 + cut,
                        y: this.y - 12 + cut
                    }
                },
                {
                    p1: {
                        x: this.x + this.slide + cut,
                        y: this.y - 12 + cut
                    },
                    p2: {
                        x: this.x + this.slide + cut,
                        y: this.y + 12 - cut
                    }
                },
                {
                    p1: {
                        x: this.x + this.slide + cut,
                        y: this.y + 12 - cut
                    },
                    p2: {
                        x: this.x + 32 + cut,
                        y: this.y + 12 - cut
                    }
                }
            ];
        }
    }
}
