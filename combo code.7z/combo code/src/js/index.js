window.game = new Game();
game.init().start();
