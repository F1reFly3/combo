<?xml version="1.0" encoding="UTF-8"?>
<tileset name="raven" tilewidth="32" tileheight="32" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="../assets/_wall.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="../assets/_floor.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="../assets/_enter.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="32" source="../assets/_exit.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="../assets/_door.png"/>
 </tile>
</tileset>
