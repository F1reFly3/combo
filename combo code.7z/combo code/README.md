diplom project from student Kuklin Dmytro PD-42 2020 DUT Kyiv 

descr: dev brouser game on JS with AI

Game name: Combo
Enemy AI name: Raven